package com.example.myapplication02;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText edtval1, edtval2;
    Button btnCalcular;
    TextView txtresultado;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtval1=findViewById(R.id.edtval1);
        edtval2=findViewById(R.id.edtval2);
        btnCalcular=findViewById(R.id.btnCalcular);
        txtresultado=findViewById(R.id.txtresultado);
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Caja1 = edtval1.getText().toString();
                String Caja2 = edtval2.getText().toString();
                if (!Caja1.equals("") && !Caja2.equals("")){
                    int Resultado;
                    Resultado = Integer.parseInt(Caja1) + Integer.parseInt(Caja2);
                    txtresultado.setText(Resultado + "");
                } else{
                    Toast.makeText(MainActivity.this, "Hay campos sin rellenar :C", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}